SELECT name, address 
FROM Customer 
WHERE status = 'H' AND name LIKE '%n';